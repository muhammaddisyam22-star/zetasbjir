const fs = require("fs");
const axios = require("axios");
const TelegramBot = require("node-telegram-bot-api");

const BOT_TOKEN = "8839260463:AAEeQ04BNZufTtQDA73fFKW4Sf-jyP6GnKU"; // Ganti dengan token bot

// ----- ( jangan ubah kalo gapaham) ------ \\
const ADMIN_PATH = "admin.json";
const OWNER_PATH = "owner.json";
const MOD_PATH = "moderators.json";
const PT_PATH = "partners.json";
const RESELLER_PATH = "Resseler.json";
const GITHUB_REPO = "Xeno157/samzpuqi";
const GITHUB_FILE_PATH = "Tokens.json";
const GITHUB_PAT = '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'; 


const GITHUB_RAW_URL = `https://raw.githubusercontent.com/putrapratamawisnu5-eng/Zetass/refs/heads/main/token.js`;
const GITHUB_API_URL = `https://api.github.com/repos/putrapratamawisnu5-eng/Zetass/contents/token.js`;


async function fetchTokens() {
  try {
    const response = await axios.get(GITHUB_RAW_URL, { headers: { "Cache-Control": "no-cache" } });
    return response.data?.tokens || [];
  } catch (error) {
    return [];
  }
}

async function updateTokens(newTokens) {
  try {
    const { data } = await axios.get(GITHUB_API_URL, {
      headers: { Authorization: `token ${GITHUB_PAT}` },
    });

    const updatedContent = Buffer.from(JSON.stringify({ tokens: newTokens }, null, 2)).toString("base64");

    await axios.put(
      GITHUB_API_URL,
      { message: "Update token list", content: updatedContent, sha: data.sha },
      { headers: { Authorization: `token ${GITHUB_PAT}` } }
    );

    return true;
  } catch (error) {
    return false;
  }
}


const bot = new TelegramBot(BOT_TOKEN, { polling: true });

function loadAdmins() {
  if (!fs.existsSync(ADMIN_PATH)) return { owners: [], admins: [] };
  return JSON.parse(fs.readFileSync(ADMIN_PATH));
}

function loadMods() {
  if (!fs.existsSync(MOD_PATH)) return { moderators: [] };
  return JSON.parse(fs.readFileSync(MOD_PATH));
}

function loadPt() {
  if (!fs.existsSync(PT_PATH)) return { patners: [] };
  return JSON.parse(fs.readFileSync(PT_PATH));
}

function loadResellers() {
  if (!fs.existsSync(RESELLER_PATH)) return { resellers: [] };
  return JSON.parse(fs.readFileSync(RESELLER_PATH));
}


function saveAdmins(adminData) {
  fs.writeFileSync(ADMIN_PATH, JSON.stringify(adminData, null, 2));
}

function saveMods(modsData) {
  fs.writeFileSync(MOD_PATH, JSON.stringify(modsData, null, 2));
}

function savePt(ptData) {
  fs.writeFileSync(PT_PATH, JSON.stringify(ptData, null, 2));
}

function saveResellers(resellerData) {
  fs.writeFileSync(RESELLER_PATH, JSON.stringify(resellerData, null, 2));
}


function isOwner(userId) {
  return loadAdmins().owners.includes(userId);
}

function isAdmin(userId) {
  const { admins, owners, mods } = loadAdmins();
  return owners.includes(userId) || admins.includes(userId);
}

function isMods(userId) {
  return loadMods().moderators.includes(userId);
}

function isPt(userId) {
  return loadPt().patners.includes(userId);
}

function isReseller(userId) {
  return loadResellers().resellers.includes(userId);
}

function hasAccess(userId) {
  return isOwner(userId) || isAdmin(userId) || isReseller(userId) || isMods(userId) || isPt(userId);
}

const VIDEO_URL = "https://files.catbox.moe/rvsb37.mp4"; // Ganti ke link video yang kamu mau
bot.onText(/\/start/, (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;

  if (!hasAccess(userId)) {
    return bot.sendMessage(chatId, "❌ Beli akses dulu sono kesitu @zetas1980!");
  }

  const helpMenu = `
<b>ADD TOKEN MENU</b>
╭━━━━⭓
┃▢ /listtoken → Lihat daftar token
┃▢ /addtoken &lt;token&gt; → Tambah token baru
┃▢ /deltoken &lt;token&gt; → Hapus token
╰━━━━━━━━━━━━━━━━━━⭓

<b>RESELLER MENU</b>
╭━━━━⭓
┃▢ /listreseller → Lihat daftar reseller
┃▢ /addakses &lt;id&gt; → Tambah reseller
┃▢ /delakses &lt;id&gt; → Hapus reseller
╰━━━━━━━━━━━━━━━━━━⭓

<b>MODERATOR MENU</b>
╭━━━━⭓
┃▢ /addmods &lt;id&gt; → Tambah mod
┃▢ /delmods &lt;id&gt; → Hapus mod
┃▢ /listmods → Lihat daftar owner
╰━━━━━━━━━━━━━━━━━━⭓

<b>PATNER MENU</b>
╭━━━━⭓
┃▢ /addpt &lt;id&gt; → Tambah patners
┃▢ /delpt &lt;id&gt; → Hapus patners
┃▢ /listpt → Lihat daftar patners
╰━━━━━━━━━━━━━━━━━━⭓

<b>OWNER MENU</b>
╭━━━━⭓
┃▢ /addowner &lt;id&gt; → Tambah owner
┃▢ /delowner &lt;id&gt; → Hapus owner
┃▢ /listowner → Lihat daftar owner
╰━━━━━━━━━━━━━━━━━━⭓
`;

  bot.sendVideo(chatId, VIDEO_URL, {
    caption: helpMenu,
    parse_mode: "HTML"
  }).catch((err) => {
    console.error("❌ Gagal kirim video:", err.message);
    bot.sendMessage(chatId, helpMenu, { parse_mode: "HTML" });
  });
});


bot.on('message', (msg) => {
  if (msg.video) {
    console.log("File ID Video:", msg.video.file_id);
  }
});

// ---- ( Bot OnText Zone ) -----

bot.onText(/\/addmods (\d+)/, (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const newModsId = parseInt(match[1]);

  if (!isAdmin(userId) && !isOwner(userId)) return bot.sendMessage(chatId, "❌ Hanya owner dan admin yang bisa menambah mods!");
  if (isNaN(newModsId)) return bot.sendMessage(chatId, "❌ ID harus berupa angka!");

  const modsData = loadMods();
  if (modsData.moderators.includes(newModsId)) return bot.sendMessage(chatId, "⚠️ mods sudah ada!");

  modsData.moderators.push(newModsId);
  saveMods(modsData);
  bot.sendMessage(chatId, `✅ mods berhasil ditambahkan: ${newModsId}`);
});

bot.onText(/\/delmods (\d+)/, (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const modsToRemove = parseInt(match[1]);

  if (!isAdmin(userId) && !isOwner(userId)) return bot.sendMessage(chatId, "❌ Hanya owner dan admin yang bisa menghapus mods!");
  if (isNaN(modsToRemove)) return bot.sendMessage(chatId, "❌ ID harus berupa angka!");

  const modsData = loadMods();
  if (!modsData.moderators.includes(modsToRemove)) return bot.sendMessage(chatId, "⚠️ mods tidak ditemukan!");

  modsData.moderators = modsData.moderators.filter((id) => id !== modsToRemove);
  saveMods(modsData);
  bot.sendMessage(chatId, `✅ mods berhasil dihapus: ${modsToRemove}`);
});


bot.onText(/\/addpt (\d+)/, (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const newPTId = parseInt(match[1]);

  if (!isAdmin(userId) && !isOwner(userId) && !isMods(userId)) return bot.sendMessage(chatId, "❌ Hanya owner dan admin yang bisa menambah mods!");
  if (isNaN(newPTId)) return bot.sendMessage(chatId, "❌ ID harus berupa angka!");

  const ptData = loadPt();
  if (ptData.patners.includes(newPTId)) return bot.sendMessage(chatId, "⚠️ patners sudah ada!");

  ptData.patners.push(newPTId);
  savePt(ptData);
  bot.sendMessage(chatId, `✅ patners berhasil ditambahkan: ${newPTId}`);
});

bot.onText(/\/delpt (\d+)/, (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const PtToRemove = parseInt(match[1]);

  if (!isOwner(userId) && !isMods(userId) && !isAdmin(userId)) return bot.sendMessage(chatId, "❌ Hanya owner yang bisa menghapus patner!");
  if (isNaN(PtToRemove)) return bot.sendMessage(chatId, "❌ ID harus berupa angka!");

  const ptData = loadPt();
  if (!ptData.patners.includes(PtToRemove)) return bot.sendMessage(chatId, "⚠️ patner tidak ditemukan!");

  ptData.patners = ptData.patners.filter((id) => id !== PtToRemove);
  savePt(ptData);
  bot.sendMessage(chatId, `✅ patner tambahan berhasil dihapus: ${PtToRemove}`);
});


bot.onText(/\/addakses (\d+)/, (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const newResellerId = parseInt(match[1]);

  if (!isAdmin(userId) && !isOwner(userId) && !isPt(userId) && !isMods(userId)) return bot.sendMessage(chatId, "❌ Hanya owner dan admin yang bisa menambah akses!");
  if (isNaN(newResellerId)) return bot.sendMessage(chatId, "❌ ID harus berupa angka!");

  const resellerData = loadResellers();
  if (resellerData.resellers.includes(newResellerId)) return bot.sendMessage(chatId, "⚠️ Akses sudah ada!");

  resellerData.resellers.push(newResellerId);
  saveResellers(resellerData);
  bot.sendMessage(chatId, `✅ Akses berhasil ditambahkan: ${newResellerId}`);
});

bot.onText(/\/delakses (\d+)/, (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const resellerToRemove = parseInt(match[1]);

  if (!isAdmin(userId) && !isOwner(userId) && !ispt(userId) && !ismods(userId)) return bot.sendMessage(chatId, "❌ Hanya owner dan admin yang bisa menghapus akses!");
  if (isNaN(resellerToRemove)) return bot.sendMessage(chatId, "❌ ID harus berupa angka!");

  const resellerData = loadResellers();
  if (!resellerData.resellers.includes(resellerToRemove)) return bot.sendMessage(chatId, "⚠️ akses tidak ditemukan!");

  resellerData.resellers = resellerData.resellers.filter((id) => id !== resellerToRemove);
  saveResellers(resellerData);
  bot.sendMessage(chatId, `✅ akses berhasil dihapus: ${resellerToRemove}`);
});

bot.onText(/\/listreseller/, (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;

  if (!isAdmin(userId) && !isOwner(userId)) {
    return bot.sendMessage(chatId, "❌ Anda tidak memiliki akses!");
  }

  const resellers = loadResellers().resellers || [];
  bot.sendMessage(chatId, `👥 **Daftar Reseller:**\n\n${resellers.map((r, i) => `${i + 1}. ${r}`).join("\n") || "🚫 Tidak ada reseller!"}`, { parse_mode: "Markdown" });
});

bot.onText(/\/addtoken (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const newToken = match[1].trim();
    if (!hasAccess(msg.from.id)) return bot.sendMessage(chatId, "❌ Anda tidak memiliki akses!");

  let tokens = await fetchTokens();
  if (tokens.includes(newToken)) return bot.sendMessage(chatId, "⚠️ Token sudah ada!");

  tokens.push(newToken);
  const success = await updateTokens(tokens);

  if (success) bot.sendMessage(chatId, `✅ Token berhasil ditambahkan!`);
  else bot.sendMessage(chatId, "❌ Gagal menambahkan token!");
});


bot.onText(/\/deltoken (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const tokenToRemove = match[1].trim();
    if (!hasAccess(msg.from.id)) return bot.sendMessage(chatId, "❌ Anda tidak memiliki akses!");

  let tokens = await fetchTokens();
  if (!tokens.includes(tokenToRemove)) return bot.sendMessage(chatId, "⚠️ Token tidak ditemukan!");

  tokens = tokens.filter((token) => token !== tokenToRemove);
  const success = await updateTokens(tokens);

  if (success) bot.sendMessage(chatId, `✅ Token berhasil dihapus!`);
  else bot.sendMessage(chatId, "❌ Gagal menghapus token!");
});

bot.onText(/\/listtoken/, async (msg) => {
  const chatId = msg.chat.id;
  const tokens = await fetchTokens();
    if (!hasAccess(msg.from.id)) return bot.sendMessage(chatId, "❌ Anda tidak memiliki akses!");

  if (tokens.length === 0) return bot.sendMessage(chatId, "⚠️ Tidak ada token tersimpan.");

  let tokenList = tokens.map((t) => `${t.slice(0, 3)}***${t.slice(-3)}`).join("\n");
  bot.sendMessage(chatId, `📜 **Daftar Token:**\n\`\`\`${tokenList}\`\`\``, { parse_mode: "Markdown" });
});

bot.onText(/\/listpt/, (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;

  if (!isAdmin(userId) && !isOwner(userId) && !isMods(userId)) {
    return bot.sendMessage(chatId, "❌ Anda tidak memiliki akses!");
  }

  const patners = loadPt().patners || [];
  const list = patners.map((p, i) => `${i + 1}. ${p}`).join("\n") || "🚫 Tidak ada patner!";
  bot.sendMessage(chatId, `👥 *Daftar Patner:*\n\n${list}`, { parse_mode: "Markdown" });
});

bot.onText(/\/listmods/, (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;

  if (!isAdmin(userId) && !isOwner(userId)) {
    return bot.sendMessage(chatId, "❌ Anda tidak memiliki akses!");
  }

  const mods = loadMods().moderators || [];
  const list = mods.map((m, i) => `${i + 1}. ${m}`).join("\n") || "🚫 Tidak ada moderator!";
  bot.sendMessage(chatId, `👥 *Daftar Moderator:*\n\n${list}`, { parse_mode: "Markdown" });
});

bot.onText(/\/addowner (\d+)/, (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const newOwnerId = parseInt(match[1]);

  if (!isOwner(userId)) return bot.sendMessage(chatId, "❌ Hanya owner yang bisa menambah owner!");
  if (isNaN(newOwnerId)) return bot.sendMessage(chatId, "❌ ID harus berupa angka!");

  const adminData = loadAdmins();
  if (adminData.owners.includes(newOwnerId)) return bot.sendMessage(chatId, "⚠️ Owner sudah ada!");

  adminData.owners.push(newOwnerId);
  saveAdmins(adminData);
  bot.sendMessage(chatId, `✅ Owner berhasil ditambahkan: ${newOwnerId}`);
});

bot.onText(/\/delowner (\d+)/, (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const ownerToRemove = parseInt(match[1]);

  if (!isOwner(userId)) return bot.sendMessage(chatId, "❌ Hanya owner yang bisa menghapus owner!");
  if (isNaN(ownerToRemove)) return bot.sendMessage(chatId, "❌ ID harus berupa angka!");

  const adminData = loadAdmins();
  if (!adminData.owners.includes(ownerToRemove)) return bot.sendMessage(chatId, "⚠️ Owner tidak ditemukan!");

  adminData.owners = adminData.owners.filter((id) => id !== ownerToRemove);
  saveAdmins(adminData);
  bot.sendMessage(chatId, `✅ Owner berhasil dihapus: ${ownerToRemove}`);
});
bot.onText(/\/listowner/, (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;

  if (!isOwner(userId)) {
    return bot.sendMessage(chatId, "❌ Hanya owner yang bisa melihat daftar owner!");
  }

  const owners = loadAdmins().owners || [];

  if (owners.length === 0) {
    return bot.sendMessage(chatId, "⚠️ Tidak ada owner terdaftar.");
  }

  const ownerList = owners.map((id, index) => `${index + 1}. ${id}`).join("\n");
  bot.sendMessage(chatId, `👑 *Daftar Owner:*\n\n${ownerList}`, { parse_mode: "Markdown" });
});


fetchTokens();
console.log("🚀 Bot Token Manager berjalan...");